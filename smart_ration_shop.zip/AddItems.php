<?php
include 'db_connect.php';

$insertdataitem = file_get_contents("php://input");
$json_data_ = json_decode($insertdataitem, true);
//$id = $json_data->id;
$id = $json_data_['id'];
$shopId =$json_data_['shopId'];
$item = $json_data_['item'];
$cardType = $json_data_['cardType'];
$qty =$json_data_['qty'];
$price = $json_data_['price'];
$avail =$json_data_['avail'];
$Updated = $json_data_['Updated'];

$sqll = "INSERT INTO shop_items (id, shopId, item, cardType, qty, price, avail, Updated)
VALUES ('$id', '$shopId', '$item', '$cardType', '$qty', '$price', '$avail', '$Updated')";

if ($conn->query($sqll) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}

$conn->close();
?>